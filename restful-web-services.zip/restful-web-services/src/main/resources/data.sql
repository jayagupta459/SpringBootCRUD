insert into user values(1001,sysdate(), 'Jaya');
insert into user values(1002,sysdate(), 'Sinha');
insert into user values(1003,sysdate(), 'Saurabh');
insert into user values(1004,sysdate(), 'Vishal');
insert into user values(1005,sysdate(), 'rajat');
insert into user values(1006,sysdate(), 'rahul');